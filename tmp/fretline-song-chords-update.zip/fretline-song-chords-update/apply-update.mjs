import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const packageRoot = dirname(fileURLToPath(import.meta.url));
const args = process.argv.slice(2);
const runTests = args.includes('--test');
const rootArgument = args.find((arg) => arg !== '--test') ?? '.';
const repositoryRoot = resolve(rootArgument);

async function copy(relativePath) {
  const source = resolve(packageRoot, relativePath);
  const destination = resolve(repositoryRoot, relativePath);
  await mkdir(dirname(destination), { recursive: true });
  await cp(source, destination, { force: true });
}

async function updateText(relativePath, transform) {
  const path = resolve(repositoryRoot, relativePath);
  const source = await readFile(path, 'utf8');
  const output = transform(source);
  if (output !== source) await writeFile(path, output, 'utf8');
}

function insertAfter(source, anchor, insertion) {
  if (source.includes(insertion.trim())) return source;
  const index = source.indexOf(anchor);
  if (index < 0) throw new Error(`Could not find patch anchor: ${anchor}`);
  const end = index + anchor.length;
  return `${source.slice(0, end)}${insertion}${source.slice(end)}`;
}

function insertBefore(source, anchor, insertion) {
  if (source.includes(insertion.trim())) return source;
  const index = source.indexOf(anchor);
  if (index < 0) throw new Error(`Could not find patch anchor: ${anchor}`);
  return `${source.slice(0, index)}${insertion}${source.slice(index)}`;
}

for (const path of [
  'src/song-chord-tray.js',
  'src/app-parts/17-song-chord-tray.js',
  'styles/song-chord-tray.css',
  'tests/song-chord-tray.test.mjs',
]) await copy(path);

await updateText('src/boot.js', (source) => {
  let output = source;
  if (!output.includes("from './song-chord-tray.js'")) {
    const importAnchor = output.includes("import * as SongGuidance from './song-guidance.js';")
      ? "import * as SongGuidance from './song-guidance.js';"
      : "import * as SongLibrary from './song-library.js';";
    output = insertAfter(output, importAnchor, "\nimport * as SongChordTray from './song-chord-tray.js';");
  }
  output = output.replace(/Object\.assign\(globalThis, ([^\n]+)\);/, (match, modules) => {
    if (modules.split(',').map((item) => item.trim()).includes('SongChordTray')) return match;
    const parts = modules.split(',').map((item) => item.trim());
    const index = Math.max(0, parts.indexOf('SongGuidance') + 1);
    parts.splice(index, 0, 'SongChordTray');
    return `Object.assign(globalThis, ${parts.join(', ')});`;
  });
  output = insertBefore(
    output,
    "  './app-parts/07-events.js',",
    "  './app-parts/17-song-chord-tray.js',\n",
  );
  return output;
});

await updateText('service-worker.js', (source) => {
  let output = source.replace(/const CACHE_NAME = 'fretline-v(\d+)'/, (_, version) => `const CACHE_NAME = 'fretline-v${Number(version) + 1}'`);
  output = insertAfter(output, "  './styles/lyrics.css',", "\n  './styles/song-chord-tray.css',");
  output = insertAfter(output, "  './src/song-guidance.js',", "\n  './src/song-chord-tray.js',");
  output = insertBefore(output, "  './src/app-parts/07-events.js',", "  './src/app-parts/17-song-chord-tray.js',\n");
  return output;
});

await updateText('package.json', (source) => {
  const data = JSON.parse(source);
  const version = String(data.version ?? '1.0.0').split('.').map(Number);
  data.version = `${version[0] || 1}.${(version[1] || 0) + 1}.0`;
  const check = String(data.scripts?.check ?? '');
  if (!check.includes('src/song-chord-tray.js')) {
    const anchor = 'node --check src/song-guidance.js';
    data.scripts.check = check.includes(anchor)
      ? check.replace(anchor, `${anchor} && node --check src/song-chord-tray.js`)
      : `${check} && node --check src/song-chord-tray.js`;
  }
  return `${JSON.stringify(data, null, 2)}\n`;
});

console.log(`Applied the compact song-chord tray to ${repositoryRoot}`);
if (runTests) {
  for (const command of [['npm', ['test']], ['npm', ['run', 'check']]]) {
    const result = spawnSync(command[0], command[1], { cwd: repositoryRoot, stdio: 'inherit' });
    if (result.status !== 0) process.exit(result.status ?? 1);
  }
}
