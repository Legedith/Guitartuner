# Compact song chord tray update

This update adds a horizontal list of every distinct chord used in the current song above the lyrics.

- Tap a chord chip or any chord above a lyric word to open its diagram.
- Use the left and right arrows to move through playable voicings.
- The compact counter shows `1/n`.
- The panel labels open shapes or the exact fret/fret range.
- The selected guitar or ukulele practice instrument controls the generated shapes.
- The current tuning is used when it matches the selected practice instrument; otherwise standard tuning is used.
- A small play control previews the sounding chord.

Apply from the root of the current Guitartuner repository:

```bash
node /path/to/fretline-song-chords-update/apply-update.mjs . --test
```

The script is idempotent and updates the boot loader, service-worker cache, package validation, source files, styles, and tests.
